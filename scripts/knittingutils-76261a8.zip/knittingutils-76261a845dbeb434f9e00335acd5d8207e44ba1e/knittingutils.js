var ks = require('./lib/knitSequence.js');
module.exports.KnitSequence = ks.KnitSequence;

module.exports.FRONT = ks.FRONT;
module.exports.BACK = ks.BACK;

var kw = require('./lib/knitoutWrapper.js');
module.exports.KnitoutWrapper = kw.KnitoutWrapper;

module.exports.LEFT = kw.LEFT;
module.exports.RIGHT = kw.RIGHT;
module.exports.NODIR = kw.NODIR;

module.exports.SWG = kw.SWG;
module.exports.SINTRAL = kw.SINTRAL;
//module.exports.KNITERATE = kw.KNITERATE;